#define _STLP_PLATFORM "Mac OS X"

#if defined (__BIG_ENDIAN__)
#  define _STLP_BIG_ENDIAN 1
#elif defined (__LITTLE_ENDIAN__)
#  define _STLP_LITTLE_ENDIAN 1
#endif

#define _STLP_USE_UNIX_IO
