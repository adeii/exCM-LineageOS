sh device/huawei/msm7x27a-common/patches/apply.sh
sh device/huawei/u8833/patches/apply.sh

add_lunch_combo lineage_u8825-eng
add_lunch_combo lineage_u8825-userdebug
add_lunch_combo lineage_u8825-user dist
add_lunch_combo lineage_u8833-eng
add_lunch_combo lineage_u8833-userdebug
add_lunch_combo lineage_u8833-user dist
add_lunch_combo lineage_u8951-eng
add_lunch_combo lineage_u8951-userdebug
add_lunch_combo lineage_u8951-user dist
