#ifndef _HAS_PM_WRAPPER_H
#define _HAS_PM_WRAPPER_H

const char* resolve_package_name(int uid);

#endif
